#read csv file
import csv
import json


def read_csv(file):
    with open(f'{file}.csv') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            print(row)
            
def lambda_handler(event, context):
    print(event)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
    
    